package application;

/**
 * Mohammed Alom
 * Student No- R00144214
 * SDH3 - Assignment Part-2 about Socket
 * Distribution System
 */

import java.util.Observer;
//Subject or handler class
public interface Subject {
	
	public void register(Observer observer);
	public void notifyObserver();
	
}
