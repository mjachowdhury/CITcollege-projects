package application;

/**
 * Mohammed Alom
 * Student No- R00144214
 * SDH3 - Assignment Part-2 about Socket
 * Distribution System
 */
import java.util.ArrayList;
import java.util.Observer;

public class ListObserver implements Subject {

	// Creating ArrayList of Observer
	private ArrayList<Observer> observers = new ArrayList<Observer>();
	private String list;

	// Constructor
	public ListObserver(String serverList) {
		super();
		this.list = serverList;
	}

	/**
	 * This method will add the observer to the arrayList
	 */
	@Override
	public void register(java.util.Observer observer) {
		// TODO Auto-generated method stub
		observers.add(observer);
	}

	/**
	 * This method will notify any change to the observer.
	 */
	@Override
	public void notifyObserver() {
		for (Observer ob : observers) {
			ob.update(null, this.list);
		}

	}

}
