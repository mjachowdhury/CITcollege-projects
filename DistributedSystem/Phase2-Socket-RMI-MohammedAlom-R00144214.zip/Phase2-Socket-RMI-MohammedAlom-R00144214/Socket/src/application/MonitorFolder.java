package application;

/**
 * Mohammed Alom
 * Student No- R00144214
 * SDH3 - Assignment Part-2 about Socket
 * Distribution System
 */
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Observable;

import application.ListObserver;

/**
 * This class is controller for the server.
 * @author Mohammed
 *
 */
public class MonitorFolder extends Observable implements MonitorInterface {

	private static volatile MonitorFolder monitorInstance = new MonitorFolder();

	// private constructor.
	private MonitorFolder() {
	}

	// Creating the instance of the MonitorFolder -Singleton
	public static MonitorFolder getInstance() {
		return monitorInstance;
	}

	private Boolean endf = false;
	private DataInputStream in;

	@Override
	public Boolean checkBool() {
		return endf;
	}

	/**
	 * This method will get all the files names from the server
	 */
	@Override
	public ArrayList<String> getNames() {

		File aDirectory = new File("G://ThirdYear//DistributedSystem//Socket//Folder1");

		String[] filesInDir = aDirectory.list();
		ArrayList<String> files = new ArrayList<String>();

		for (int i = 0; i < filesInDir.length; i++) {
			if (filesInDir[i].endsWith(".mp3")) {
				files.add(filesInDir[i]);
			}
		}
		return files;
	}

	@Override
	public Boolean openFile1(String name) {
		try {
			in = new DataInputStream(new BufferedInputStream(new FileInputStream(name)));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return true;
	}

	@Override
	public byte[] getB(File file) {

		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		byte[] buf = new byte[1024];

		try {
			for (int readNum; (readNum = fis.read(buf)) != -1;) {
				bos.write(buf, 0, readNum);
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		byte[] bytes = bos.toByteArray();

		return bytes;
	}

	@Override
	public void copyFile(byte[] bytes, String songName) throws IOException {

		File someFile = new File("G://ThirdYear//DistributedSystem//Socket//Folder1//" + songName);
		FileOutputStream fos = new FileOutputStream(someFile);
		fos.write(bytes);
		fos.flush();
		fos.close();
	}

	@Override
	public Boolean closeFile() {
		try {
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * This method will notify any change to the server/ observer
	 * 
	 * @param items
	 * @return
	 */
	public Boolean checkForChange(ArrayList<String> items) {

		Boolean bool;

		File aDirectory2 = new File("G://ThirdYear//DistributedSystem//Socket//Folder1");
		String[] filesInDir2 = aDirectory2.list();

		ArrayList<String> ls2 = new ArrayList<String>(Arrays.asList());

		for (int i = 0; i < filesInDir2.length; i++) {
			if (filesInDir2[i].endsWith(".mp3")) {
				ls2.add(filesInDir2[i]);
			}
		}
		if (items.size() != ls2.size()) {
			String serverList = "Server";
			ListObserver ListObserver = new ListObserver(serverList);
			Server serverClass = new Server();
			ListObserver.register(serverClass);
			ListObserver.notifyObserver();
			bool = true;
		} else {
			bool = false;
		}
		return bool;
	}

}
