package application;

/**
 * Mohammed Alom
 * Student No- R00144214
 * SDH3 - Assignment Part-2 about Socket
 * Distribution System
 */
public interface Observer {
	public void update(String list);
}
