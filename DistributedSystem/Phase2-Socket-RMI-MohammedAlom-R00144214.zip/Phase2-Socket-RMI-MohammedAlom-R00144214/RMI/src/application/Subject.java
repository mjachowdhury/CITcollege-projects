package application;

/**
 * Mohammed Alom
 * Student No- R00144214
 * SDH3 - Assignment Part-2 about RMI
 * Distribution System
 */

import java.util.Observer;

public interface Subject {

	public void register(Observer observer);

	public void notifyObserver();

}
