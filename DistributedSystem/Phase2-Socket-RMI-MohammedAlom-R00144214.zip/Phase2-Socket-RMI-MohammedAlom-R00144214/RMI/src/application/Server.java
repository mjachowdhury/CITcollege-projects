package application;

/**
 * Mohammed Alom
 * Student No- R00144214
 * SDH3 - Assignment Part-2 about RMI
 * Distribution System
 */

import java.nio.channels.AlreadyBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Server {
	
	private static final int PORT = 5555;//port number
	private static Registry registry;

	public static void startRegistry() throws RemoteException {
		// Create server registry
		registry = LocateRegistry.createRegistry(PORT);
	}

	public static void registerObject(String name, Remote remoteObj)
			throws RemoteException, AlreadyBoundException, java.rmi.AlreadyBoundException {
		registry.bind(name, remoteObj);
		System.out.println("Registered: " + name + " -> " + remoteObj.getClass().getName());
	}

	public static void main(String[] args) throws Exception {
		System.out.println("Server starting...");
		startRegistry();
		registerObject(MonitorInterface.class.getSimpleName(), new MonitorFolder());
		System.out.println("Server started!");
	}
}
