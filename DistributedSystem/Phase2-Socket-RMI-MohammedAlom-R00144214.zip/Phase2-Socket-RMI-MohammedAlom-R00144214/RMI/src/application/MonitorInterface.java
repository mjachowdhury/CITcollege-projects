package application;

/**
 * Mohammed Alom
 * Student No- R00144214
 * SDH3 - Assignment Part-2 about RMI
 * Distribution System
 */
//import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

//import javafx.collections.ObservableList;

public interface MonitorInterface extends Remote {

	public Boolean checkBool() throws RemoteException; // returns a bool

	public ArrayList<String> getNames() throws RemoteException; // returns name of all files in folder 1

	public Boolean openFile1(String name) throws RemoteException; // opens a file called name

	public byte[] getB(String songName) throws RemoteException; // gets a byte from currently opened file

	public Boolean closeFile() throws RemoteException; // closes a file

	public Boolean checkForChange(ArrayList<String> items) throws RemoteException;

	public void copyFile(byte[] bytes, String songName) throws FileNotFoundException, IOException, RemoteException;
}
