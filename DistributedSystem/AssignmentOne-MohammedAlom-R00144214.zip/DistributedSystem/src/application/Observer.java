package application;

/**
 * Student Name - Mohammed Alom
 * Student No - R00144214 - SDH3
 */
public interface Observer {
	public void update(String list);
}
