package application;

/**
 * Student Name - Mohammed Alom
 * Student No - R00144214 - SDH3
 */
import java.util.Observer;

public interface Subject {

	public void register(Observer observer);

	public void notifyObserver();

}
