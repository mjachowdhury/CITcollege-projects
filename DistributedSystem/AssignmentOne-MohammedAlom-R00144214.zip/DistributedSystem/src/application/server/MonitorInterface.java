package application.server;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

public interface MonitorInterface extends Remote {

	// returns a bool
	public Boolean checkBool() throws RemoteException; 

	// returns name of all files in folder 1
	public ArrayList<String> getNames() throws RemoteException; 

	// opens a file called name
	public Boolean openFile1(String name) throws RemoteException; 

	// gets a byte from currently opened file
	public byte[] getB(String songName) throws RemoteException; 

	// closes a file
	public Boolean closeFile() throws RemoteException; 

	public Boolean checkForChange(ArrayList<String> items) throws RemoteException;

	public void copyFile(byte[] bytes, String songName) throws FileNotFoundException, IOException, RemoteException;
}
