package application.server;

/**
 * Student Name - Mohammed Alom
 * Student No - R00144214 - SDH3
 */
import java.nio.channels.AlreadyBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Server {
	private static final int PORT = 5555;
	//static int PORT = 5555;
	private static Registry registry;
	//static Registry registry;

	public static void startRegistry() throws RemoteException {
		// Create server registry
		registry = LocateRegistry.createRegistry(PORT);
	}

	/**
	 * This method will registered once the media player start
	 * @param name
	 * @param remoteObj
	 * @throws RemoteException
	 * @throws AlreadyBoundException
	 * @throws java.rmi.AlreadyBoundException
	 */
	public static void registerObject(String name, Remote remoteObj)
			throws RemoteException, AlreadyBoundException, java.rmi.AlreadyBoundException {
		registry.bind(name, remoteObj);
		System.out.println("Registered: " + name + " -> " + remoteObj.getClass().getName());
	}

	/**
	 * Starting the the server
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		System.out.println("Server starting...");
		startRegistry();
		registerObject(MonitorInterface.class.getSimpleName(), new MonitorFolder());
		System.out.println("Server started!");
	}
}
