package com.mohammed.transport;

public class PayPalConfig {
    public static final String PAYPAL_CLIENT_ID = "AbsHQFDncI_cAdy1dTtBXSB2znBJi3Y-BxXoLhDrtuQiiKju_6j_Lk4W6wHjSZ1syn1wy8Rwsh8w_IkZ";
}
