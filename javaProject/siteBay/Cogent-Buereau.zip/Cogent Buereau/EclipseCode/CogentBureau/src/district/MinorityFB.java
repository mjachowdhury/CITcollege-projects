// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 10/1/2009 6:10:00 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   MinorityFB.java

package district;

import org.apache.struts.validator.DynaValidatorForm;

public class MinorityFB extends DynaValidatorForm
{

    public MinorityFB()
    {
    }
}