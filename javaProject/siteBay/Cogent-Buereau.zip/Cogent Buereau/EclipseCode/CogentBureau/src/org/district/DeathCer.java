// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 10/1/2009 5:50:08 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   DeathCer.java

package org.district;


public class DeathCer
{

    public DeathCer()
    {
    }

    public void setDcid(String dcid)
    {
        this.dcid = dcid;
    }

    public String getDcid()
    {
        return dcid;
    }

    public void setFname(String fname)
    {
        this.fname = fname;
    }

    public String getFname()
    {
        return fname;
    }

    public void setLname(String lname)
    {
        this.lname = lname;
    }

    public String getLname()
    {
        return lname;
    }

    public void setFather(String father)
    {
        this.father = father;
    }

    public String getFather()
    {
        return father;
    }

    public void setMname(String mname)
    {
        this.mname = mname;
    }

    public String getMname()
    {
        return mname;
    }

    public void setRadd(String radd)
    {
        this.radd = radd;
    }

    public String getRadd()
    {
        return radd;
    }

    public void setPadd(String padd)
    {
        this.padd = padd;
    }

    public String getPadd()
    {
        return padd;
    }

    public void setDob(String dob)
    {
        this.dob = dob;
    }

    public String getDob()
    {
        return dob;
    }

    public void setDod(String dod)
    {
        this.dod = dod;
    }

    public String getDod()
    {
        return dod;
    }

    public void setSex(String sex)
    {
        this.sex = sex;
    }

    public String getSex()
    {
        return sex;
    }

    public void setCast(String cast)
    {
        this.cast = cast;
    }

    public String getCast()
    {
        return cast;
    }

    public void setDplace(String dplace)
    {
        this.dplace = dplace;
    }

    public String getDplace()
    {
        return dplace;
    }

    public void setDrname(String drname)
    {
        this.drname = drname;
    }

    public String getDrname()
    {
        return drname;
    }

    public void setReason(String reason)
    {
        this.reason = reason;
    }

    public String getReason()
    {
        return reason;
    }

    public void setOccup(String occup)
    {
        this.occup = occup;
    }

    public String getOccup()
    {
        return occup;
    }

    public void setDor(String dor)
    {
        this.dor = dor;
    }

    public String getDor()
    {
        return dor;
    }

    public void setFlag(int flag)
    {
        this.flag = flag;
    }

    public int getFlag()
    {
        return flag;
    }

    public void setHospital(String hospital)
    {
        this.hospital = hospital;
    }

    public String getHospital()
    {
        return hospital;
    }

    private String dcid;
    private String fname;
    private String lname;
    private String father;
    private String mname;
    private String radd;
    private String padd;
    private String dob;
    private String dod;
    private String sex;
    private String cast;
    private String dplace;
    private String drname;
    private String reason;
    private String occup;
    private String dor;
    private int flag;
    private String hospital;
}