// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 10/1/2009 5:51:19 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   PassportCer.java

package org.district;


public class PassportCer
{

    public PassportCer()
    {
    }

    public void setBcid(String bcid)
    {
        this.bcid = bcid;
    }

    public String getBcid()
    {
        return bcid;
    }

    public void setFname(String fname)
    {
        this.fname = fname;
    }

    public String getFname()
    {
        return fname;
    }

    public void setSname(String sname)
    {
        this.sname = sname;
    }

    public String getSname()
    {
        return sname;
    }

    public void setRadd(String radd)
    {
        this.radd = radd;
    }

    public String getRadd()
    {
        return radd;
    }

    public void setPadd(String padd)
    {
        this.padd = padd;
    }

    public String getPadd()
    {
        return padd;
    }

    public void setLname(String lname)
    {
        this.lname = lname;
    }

    public String getLname()
    {
        return lname;
    }

    public void setFather(String father)
    {
        this.father = father;
    }

    public String getFather()
    {
        return father;
    }

    public void setMname(String mname)
    {
        this.mname = mname;
    }

    public String getMname()
    {
        return mname;
    }

    public void setDob(String dob)
    {
        this.dob = dob;
    }

    public String getDob()
    {
        return dob;
    }

    public void setSex(String sex)
    {
        this.sex = sex;
    }

    public String getSex()
    {
        return sex;
    }

    public void setBplace(String bplace)
    {
        this.bplace = bplace;
    }

    public String getBplace()
    {
        return bplace;
    }

    public void setTelno(String telno)
    {
        this.telno = telno;
    }

    public String getTelno()
    {
        return telno;
    }

    public void setMobileno(String mobileno)
    {
        this.mobileno = mobileno;
    }

    public String getMobileno()
    {
        return mobileno;
    }

    public void setEmailid(String emailid)
    {
        this.emailid = emailid;
    }

    public String getEmailid()
    {
        return emailid;
    }

    public void setQul(String qul)
    {
        this.qul = qul;
    }

    public String getQul()
    {
        return qul;
    }

    public void setProf(String prof)
    {
        this.prof = prof;
    }

    public String getProf()
    {
        return prof;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getId()
    {
        return id;
    }

    public void setHeight(String height)
    {
        this.height = height;
    }

    public String getHeight()
    {
        return height;
    }

    public void setFlag(int flag)
    {
        this.flag = flag;
    }

    public int getFlag()
    {
        return flag;
    }

    private String bcid;
    private String fname;
    private String lname;
    private String dob;
    private String sex;
    private String sname;
    private String father;
    private String mname;
    private String bplace;
    private String telno;
    private String mobileno;
    private String emailid;
    private String qul;
    private String prof;
    private String id;
    private String height;
    private String radd;
    private String padd;
    private int flag;
}