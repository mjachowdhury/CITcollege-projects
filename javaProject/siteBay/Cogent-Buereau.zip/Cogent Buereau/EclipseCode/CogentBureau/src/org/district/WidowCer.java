// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 10/1/2009 5:51:57 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   WidowCer.java

package org.district;


public class WidowCer
{

    public WidowCer()
    {
    }

    public void setWcid(String wcid)
    {
        this.wcid = wcid;
    }

    public String getWcid()
    {
        return wcid;
    }

    public void setFname(String fname)
    {
        this.fname = fname;
    }

    public String getFname()
    {
        return fname;
    }

    public void setLname(String lname)
    {
        this.lname = lname;
    }

    public String getLname()
    {
        return lname;
    }

    public void setHname(String hname)
    {
        this.hname = hname;
    }

    public String getHname()
    {
        return hname;
    }

    public void setRadd(String radd)
    {
        this.radd = radd;
    }

    public String getRadd()
    {
        return radd;
    }

    public void setPadd(String padd)
    {
        this.padd = padd;
    }

    public String getPadd()
    {
        return padd;
    }

    public void setDcid(String dcid)
    {
        this.dcid = dcid;
    }

    public String getDcid()
    {
        return dcid;
    }

    public void setDod(String dod)
    {
        this.dod = dod;
    }

    public String getDod()
    {
        return dod;
    }

    public void setDplace(String dplace)
    {
        this.dplace = dplace;
    }

    public String getDplace()
    {
        return dplace;
    }

    public void setDrname(String drname)
    {
        this.drname = drname;
    }

    public String getDrname()
    {
        return drname;
    }

    public void setReason(String reason)
    {
        this.reason = reason;
    }

    public String getReason()
    {
        return reason;
    }

    public void setOccup(String occup)
    {
        this.occup = occup;
    }

    public String getOccup()
    {
        return occup;
    }

    public void setDor(String dor)
    {
        this.dor = dor;
    }

    public String getDor()
    {
        return dor;
    }

    public void setFlag(int flag)
    {
        this.flag = flag;
    }

    public int getFlag()
    {
        return flag;
    }

    public void setHospital(String hospital)
    {
        this.hospital = hospital;
    }

    public String getHospital()
    {
        return hospital;
    }

    private String wcid;
    private String fname;
    private String lname;
    private String hname;
    private String radd;
    private String padd;
    private String dcid;
    private String dod;
    private String dplace;
    private String drname;
    private String reason;
    private String occup;
    private String dor;
    private int flag;
    private String hospital;
}