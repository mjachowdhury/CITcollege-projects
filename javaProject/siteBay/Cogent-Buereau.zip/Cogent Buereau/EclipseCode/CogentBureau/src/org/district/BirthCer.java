package org.district;


public class BirthCer
{

    public BirthCer()
    {
    }

    public void setBcid(String bcid)
    {
        this.bcid = bcid;
    }

    public String getBcid()
    {
        return bcid;
    }

    public void setFname(String fname)
    {
        this.fname = fname;
    }

    public String getFname()
    {
        return fname;
    }

    public void setLname(String lname)
    {
        this.lname = lname;
    }

    public String getLname()
    {
        return lname;
    }

    public void setFather(String father)
    {
        this.father = father;
    }

    public String getFather()
    {
        return father;
    }

    public void setMname(String mname)
    {
        this.mname = mname;
    }

    public String getMname()
    {
        return mname;
    }

    public void setRadd(String radd)
    {
        this.radd = radd;
    }

    public String getRadd()
    {
        return radd;
    }

    public void setPadd(String padd)
    {
        this.padd = padd;
    }

    public String getPadd()
    {
        return padd;
    }

    public void setDob(String dob)
    {
        this.dob = dob;
    }

    public String getDob()
    {
        return dob;
    }

    public void setSex(String sex)
    {
        this.sex = sex;
    }

    public String getSex()
    {
        return sex;
    }

    public void setCast(String cast)
    {
        this.cast = cast;
    }

    public String getCast()
    {
        return cast;
    }

    public void setBplace(String bplace)
    {
        this.bplace = bplace;
    }

    public String getBplace()
    {
        return bplace;
    }

    public void setDrname(String drname)
    {
        this.drname = drname;
    }

    public String getDrname()
    {
        return drname;
    }

    public void setFoccup(String foccup)
    {
        this.foccup = foccup;
    }

    public String getFoccup()
    {
        return foccup;
    }

    public void setDor(String dor)
    {
        this.dor = dor;
    }

    public String getDor()
    {
        return dor;
    }

    public void setFlag(int flag)
    {
        this.flag = flag;
    }

    public int getFlag()
    {
        return flag;
    }

    public void setHospital(String hospital)
    {
        this.hospital = hospital;
    }

    public String getHospital()
    {
        return hospital;
    }

    private String bcid;
    private String fname;
    private String lname;
    private String father;
    private String mname;
    private String radd;
    private String padd;
    private String dob;
    private String sex;
    private String cast;
    private String bplace;
    private String drname;
    private String foccup;
    private String dor;
    private int flag;
    private String hospital;
}