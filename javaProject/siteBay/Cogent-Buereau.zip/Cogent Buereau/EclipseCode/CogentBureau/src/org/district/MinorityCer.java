// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 10/1/2009 5:51:01 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   MinorityCer.java

package org.district;


public class MinorityCer
{

    public MinorityCer()
    {
    }

    public void setMcid(String mcid)
    {
        this.mcid = mcid;
    }

    public String getMcid()
    {
        return mcid;
    }

    public void setFname(String fname)
    {
        this.fname = fname;
    }

    public String getFname()
    {
        return fname;
    }

    public void setLname(String lname)
    {
        this.lname = lname;
    }

    public String getLname()
    {
        return lname;
    }

    public void setFather(String father)
    {
        this.father = father;
    }

    public String getFather()
    {
        return father;
    }

    public void setRadd(String radd)
    {
        this.radd = radd;
    }

    public String getRadd()
    {
        return radd;
    }

    public void setPadd(String padd)
    {
        this.padd = padd;
    }

    public String getPadd()
    {
        return padd;
    }

    public void setDob(String dob)
    {
        this.dob = dob;
    }

    public String getDob()
    {
        return dob;
    }

    public void setSex(String sex)
    {
        this.sex = sex;
    }

    public String getSex()
    {
        return sex;
    }

    public void setPurpose(String purpose)
    {
        this.purpose = purpose;
    }

    public String getPurpose()
    {
        return purpose;
    }

    public void setOccup(String occup)
    {
        this.occup = occup;
    }

    public String getOccup()
    {
        return occup;
    }

    public void setReligion(String religion)
    {
        this.religion = religion;
    }

    public String getReligion()
    {
        return religion;
    }

    public void setDor(String dor)
    {
        this.dor = dor;
    }

    public String getDor()
    {
        return dor;
    }

    public void setFlag(int flag)
    {
        this.flag = flag;
    }

    public int getFlag()
    {
        return flag;
    }

    public void setIncome(double income)
    {
        this.income = income;
    }

    public double getIncome()
    {
        return income;
    }

    private String mcid;
    private String fname;
    private String lname;
    private String father;
    private String radd;
    private String padd;
    private String dob;
    private String sex;
    private String purpose;
    private String religion;
    private String occup;
    private String dor;
    private int flag;
    private double income;
}