// SI lang variables ISO-8859-2

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Najdi',
searchreplace_searchnext_desc : 'Ponovno najdi',
searchreplace_replace_desc : 'Najdi/zamenjaj',
searchreplace_notfound : 'Iskanje je bilo zaklju&#269;eno. Ne najdem iskanega zaporedja',
searchreplace_search_title : 'Najdi',
searchreplace_replace_title : 'Najdi/zamenjaj',
searchreplace_allreplaced : 'Vse pojavitve iskanega zaporedja so bile zamenjane.',
searchreplace_findwhat : 'Najdi',
searchreplace_replacewith : 'Zamenjaj z',
searchreplace_direction : 'Smer',
searchreplace_up : 'Gor',
searchreplace_down : 'Dol',
searchreplace_case : 'Upo&#353;tevaj velike/male &#269;rke',
searchreplace_findnext : 'Najdi nasledno pojavitev',
searchreplace_replace : 'Zamenjaj',
searchreplace_replaceall : 'Zamenjaj vse',
searchreplace_cancel : 'Prekli&#269;i'
});
