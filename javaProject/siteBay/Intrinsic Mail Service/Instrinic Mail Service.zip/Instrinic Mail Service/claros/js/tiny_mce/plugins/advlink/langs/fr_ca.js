// CA_FR lang variables

tinyMCE.addToLang('',{
insert_link_target_same : 'Ouvrir dans la m�me fen�tre',
insert_link_target_parent : 'Ouvrir dans la fen�tre parent',
insert_link_target_top : 'Ouvrir dans le cadre sup�rieur',
insert_link_target_blank : 'Ouvrir dans une nouvelle fen�tre',
insert_link_target_named : 'Ouvrir � la destination',
insert_link_popup : 'JS-Popup',
insert_link_popup_url : 'URL du popup',
insert_link_popup_name : 'Nom de la fen�tre',
insert_link_popup_return : 'Ins�rer le script \'return false\'',
insert_link_popup_scrollbars : 'Barres de d�filement',
insert_link_popup_statusbar : 'Barre de statut',
insert_link_popup_toolbar : 'Barres d\'outils',
insert_link_popup_menubar : 'Barre de menu',
insert_link_popup_location : 'Barre d\'adresse',
insert_link_popup_resizable : 'Fen�tre redimensionnable',
insert_link_popup_size : 'Dimensions',
insert_link_popup_position : 'Position (X/Y)',
insert_link_popup_missingtarget : 'S.v.p., entrer un nom de destination ou choisir une autre option.'
});
