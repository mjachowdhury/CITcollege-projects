// NL lang variables

tinyMCE.addToLang('flash',{
title : 'Flash bestand invoegen/bewerken',
desc : 'Flash bestand invoegen/bewerken',
file : 'Flash bestand (.swf)',
size : 'Grootte',
list : 'Flash bestanden',
props : 'Flash eigenschappen',
general : 'Algemeen'
});
