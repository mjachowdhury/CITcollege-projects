// DK lang variables contributed by Jan Moelgaard, John Dalsgaard and Bo Frederiksen.

tinyMCE.addToLang('emotions',{
title : 'Inds&aelig;t smiley',
desc : 'Smileys',
cool : 'Sej',
cry : 'Gr&aring;d',
embarassed : 'Forlegen',
foot_in_mouth : 'Foden i munden',
frown : 'Rynket pande',
innocent : 'Uskyldig',
kiss : 'Kys',
laughing : 'Latter',
money_mouth : 'L&aelig;kker mund',
sealed : 'Lukket af',
smile : 'Smil',
surprised : 'Overrasket',
tongue_out : 'R&aelig;k tunge',
undecided : 'Usikker',
wink : 'Blink',
yell : 'R&aring;b'
});
