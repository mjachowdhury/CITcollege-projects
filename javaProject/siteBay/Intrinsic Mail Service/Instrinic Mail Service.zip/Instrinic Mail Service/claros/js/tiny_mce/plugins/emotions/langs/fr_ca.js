// Canadian French lang variables by Virtuelcom   last modification: 2005-06-15

tinyMCE.addToLang('',{
insert_emotions_title : 'Ins�rer un �moticon',
emotions_desc : '�moticons'
});
