// DK lang variables contributed by Jan Moelgaard, John Dalsgaard and Bo Frederiksen.

tinyMCE.addToLang('advimage',{
tab_general : 'Generelt',
tab_appearance : 'Udseende',
tab_advanced : 'Avanceret',
general : 'Generelt',
title : 'Overskrift',
preview : 'Se',
constrain_proportions : 'Fasthold proportioner',
langdir : 'Tekstretning',
langcode : 'Sprogkode',
long_desc : 'Langt beskrivelseslink',
style : 'Style',
classes : 'Klasser',
ltr : 'Venstre til h&oslash;jre',
rtl : 'H&oslash;jre til venstre',
id : 'Id',
image_map : 'Billedkort',
swap_image : 'Alternativt billede',
alt_image : 'Alternative image',
mouseover : 'ved mouse over',
mouseout : 'ved mouse out',
misc : 'Diverse',
example_img : 'Appearance&nbsp;preview&nbsp;image',
missing_alt : 'Er du sikker p&aring; at du vil forts&aelig;tte uden at inds&aelig;tte en billedbeskrivelse? Uden den, kan billedet v&aelig;re utilg&aelig;ngeligt for brugere med handicap, eller for brugere med en tekst-browser, eller som har sl&aring;et billedvisning fra.'
});
