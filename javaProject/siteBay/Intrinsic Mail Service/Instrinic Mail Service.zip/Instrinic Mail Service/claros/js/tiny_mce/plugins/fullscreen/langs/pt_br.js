/**
 * pt_br lang variables
 * Brazilian Portuguese
 *
 * Authors : ????
 * Revision and modifications:
 *           Marcio Barbosa (mpg) <mpg@mpg.com.br>
 * Last Updated : November 26, 2005
 * TinyMCE Version : 2.0RC4
 */
tinyMCE.addToLang('',{
fullscreen_title : 'Modo de Janela Inteira (Fullscreen)',
fullscreen_desc : 'Alterar para modo de janela inteira'
});
