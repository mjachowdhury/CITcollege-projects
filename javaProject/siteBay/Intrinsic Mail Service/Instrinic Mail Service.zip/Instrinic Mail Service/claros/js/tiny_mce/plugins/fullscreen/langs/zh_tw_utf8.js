// Traditional Chinese UTF-8; Twapweb Site translated; twapweb_AT_gmail_DOT_com
// 繁體中文 UTF-8 ；數位應用坊製作； twapweb_AT_gmail_DOT_com

tinyMCE.addToLang('',{
fullscreen_title : '全螢幕模式',
fullscreen_desc : '轉成全螢幕模式'
});
