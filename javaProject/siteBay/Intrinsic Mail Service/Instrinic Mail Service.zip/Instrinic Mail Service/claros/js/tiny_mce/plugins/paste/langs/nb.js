// nb = Norwegian (bokm&aring;l) lang variables by Knut B. Jacobsen

tinyMCE.addToLang('',{
paste_text_desc : 'Lim inn som vanlig tekst',
paste_text_title : 'Bruk CTRL+V p&aring; tastaturet ditt for &aring; lime inn i dette vinduet.',
paste_text_linebreaks : 'Spar linjebrudd',
paste_word_desc : 'Lim inn fra Office (Word)',
paste_word_title : 'Bruk CTRL+V p&aring; tastaturet ditt for &aring; lime inn i dette vinduet.',
selectall_desc : 'Velg alt'
});
