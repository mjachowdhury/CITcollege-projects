// PL lang variables
// fixed by Wooya
// http://www.mfusion.prv.pl
// fixed by lemiel 14.11.2005

tinyMCE.addToLang('',{
insertdate_def_fmt : '%Y-%m-%d',
inserttime_def_fmt : '%H:%M:%S',
insertdate_desc : 'Wstaw aktualn� dat�',
inserttime_desc : 'Wstaw aktualny czas',
inserttime_months_long : new Array("Stycze�", "Luty", "Marzec", "Kwiecie�", "Maj", "Czerwiec", "Lipiec", "Sierpie�", "Wrzesie�", "Pa�dziernik", "Listopad", "Grudzie�"),
inserttime_months_short : new Array("Sty", "Lut", "Mar", "Kwi", "Maj", "Czer", "Lip", "Sier", "Wrze", "Pa�", "List", "Grudz"),
inserttime_day_long : new Array("Niedziela", "Poniedzia�ek", "Wtorek", "�roda", "Czwartek", "Pi�tek", "Sobota", "Niedziela"),
inserttime_day_short : new Array("Nie", "Pon", "Wto", "�ro", "Czw", "Pi�", "Sob", "Nie")
});
