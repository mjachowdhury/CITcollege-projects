// ES lang variables by Alvaro Velasco and Adolfo Sanz De Diego (asanzdiego) <asanzdiego@yahoo.es>
// Last Updated : October 2005
// TinyMCE Version : 2.0RC3

tinyMCE.addToLang('',{
print_desc : 'Imprimir'
});
