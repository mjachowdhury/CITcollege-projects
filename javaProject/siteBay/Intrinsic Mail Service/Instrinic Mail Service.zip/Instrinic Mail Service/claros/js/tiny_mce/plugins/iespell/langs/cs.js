/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.5 2006/01/11 14:25:48 spocke Exp $ 
 */  

tinyMCE.addToLang('',{
iespell_desc : 'Spustit kontrolu pravopisu',
iespell_download : "ieSpell nedetekován. Klikněte na OK a otevřete stahovací stránku."
});

