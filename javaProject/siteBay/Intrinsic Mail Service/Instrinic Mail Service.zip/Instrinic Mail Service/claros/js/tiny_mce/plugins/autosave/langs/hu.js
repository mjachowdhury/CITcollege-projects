// HU lang variables

tinyMCE.addToLang('',{
autosave_unload_msg : 'A m�dos�t�sok el fognak veszni, ha elnavig�lsz az oldalr�l.'
});
