// RU UTF-8 lang variables

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */

tinyMCE.addToLang('',{
template_title : 'Это шаблон для popup',
template_desc : 'Это шаблон для кнопки'
});
