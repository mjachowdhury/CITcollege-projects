/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.5 2006/01/11 14:25:47 spocke Exp $ 
 */  

tinyMCE.addToLang('',{
insert_advhr_desc : 'Vložit/editovat vodorovný oddělovač',
insert_advhr_width : 'Šířka',
insert_advhr_size : 'Výška',
insert_advhr_noshade : 'Nestínovat'
});

