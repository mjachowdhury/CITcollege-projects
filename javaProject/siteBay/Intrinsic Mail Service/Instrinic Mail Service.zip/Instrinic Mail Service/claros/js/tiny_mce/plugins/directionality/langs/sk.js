/**
 * Slovak lang variables 
 * encoding: utf-8
 * 
 * @author Vladimir VASIL vvasil@post.sk
 *    
 * $Id: sk.js,v 1.1 2005/11/22 20:56:44 spocke Exp $ 
 */  

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Smer z ľava doprava',
directionality_rtl_desc : 'Smer z prava doľava'
});

