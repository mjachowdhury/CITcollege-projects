// DE lang variables 

tinyMCE.addToLang('',{
print_desc : 'Drucken'
});
