// HU lang variables

tinyMCE.addToLang('',{
print_desc : 'Nyomtat�s'
});
