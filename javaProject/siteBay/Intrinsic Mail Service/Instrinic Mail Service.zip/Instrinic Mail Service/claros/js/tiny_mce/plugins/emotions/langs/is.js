// Iceland lang variables by Johannes Birgir Jensson

tinyMCE.addToLang('emotions',{
title : 'Tilfinningat&aacute;kn',
desc : 'Tilfinningat&aacute;kn',
cool : 'Svalur',
cry : 'Gr&aacute;ta',
embarassed : 'Sk&ouml;mmustulegur',
foot_in_mouth : 'Tala af s&eacute;r',
frown : 'F&yacute;ldur',
innocent : 'Saklaus',
kiss : 'Koss',
laughing : 'Hl&aelig;jandi',
money_mouth : 'Gr&aacute;&eth;ugur',
sealed : '&THORN;&ouml;gull sem gr&ouml;fin',
smile : 'Brosandi',
surprised : 'Hissa',
tongue_out : 'Ullandi',
undecided : '&Oacute;&aacute;kve&eth;inn',
wink : 'Glottandi',
yell : '&Ouml;skrandi'
});
