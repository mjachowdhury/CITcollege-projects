// DE lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Von links nach rechts',
directionality_rtl_desc : 'Von rechts nach links'
});
