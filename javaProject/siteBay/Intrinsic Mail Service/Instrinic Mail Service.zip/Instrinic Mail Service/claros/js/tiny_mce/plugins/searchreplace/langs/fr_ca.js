// Canadian French lang variables by Virtuelcom   last modification: 2005-06-15

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Chercher',
searchreplace_searchnext_desc : 'Chercher suivant',
searchreplace_replace_desc : 'Chercher/Remplacer',
searchreplace_notfound : 'La recherche est termin�e.  Aucune occurence trouv�e.',
searchreplace_search_title : 'Chercher',
searchreplace_replace_title : 'Chercher/Remplacer',
searchreplace_allreplaced : 'Toutes les occurences ont �t� remplac�es.',
searchreplace_findwhat : 'Chercher quoi',
searchreplace_replacewith : 'Remplacer par',
searchreplace_direction : 'Direction',
searchreplace_up : 'Monter',
searchreplace_down : 'Descendre',
searchreplace_case : 'Sensible � la case',
searchreplace_findnext : 'Chercher&nbsp,suivant',
searchreplace_replace : 'Remplacer',
searchreplace_replaceall : 'Remplacer&nbsp,tous',
searchreplace_cancel : 'Annuler'
});
