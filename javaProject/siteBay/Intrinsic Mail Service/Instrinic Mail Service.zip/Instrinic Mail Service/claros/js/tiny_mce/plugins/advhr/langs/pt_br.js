/**
 * pt_br lang variables
 * Brazilian Portuguese
 *
 * Authors : ????
 * Revision and modifications:
 *           Marcio Barbosa (mpg) <mpg@mpg.com.br>
 * Last Updated : November 26, 2005
 * TinyMCE Version : 2.0RC4
 */
tinyMCE.addToLang('',{
insert_advhr_desc : 'Inserir / editar Linha Horizontal',
insert_advhr_width : 'Largura',
insert_advhr_size : 'Altura',
insert_advhr_noshade : 'Sem Sombra'
});
