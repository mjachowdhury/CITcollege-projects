// Traduit par Normand Lamoureux le 2005-11-12

tinyMCE.addToLang('flash',{
title : 'Gestionnaire d\'animation Flash',
desc : 'Ins�rer une animation Flash',
file : 'Fichier Flash (.swf)',
size : 'Taille',
list : 'Fichiers Flash',
props : 'Propri�t�s Flash',
general : 'G�n�ral'
});
