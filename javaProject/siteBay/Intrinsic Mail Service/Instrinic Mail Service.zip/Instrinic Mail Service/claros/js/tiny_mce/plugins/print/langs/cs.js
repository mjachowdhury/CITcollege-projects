/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.4 2005/10/18 13:59:43 spocke Exp $ 
 */  

tinyMCE.addToLang('',{
print_desc : 'Tisk'
});

