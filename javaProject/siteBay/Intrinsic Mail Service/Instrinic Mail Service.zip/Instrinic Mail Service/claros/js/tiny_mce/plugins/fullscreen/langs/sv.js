// SV lang variables

tinyMCE.addToLang('',{
fullscreen_title : 'Fullsk&auml;rmsl&auml;ge',
fullscreen_desc : 'Hoppa fr&aring;n/till fullsk&auml;rmsl&auml;ge'
});
