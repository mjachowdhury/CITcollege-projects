// UK lang variables

tinyMCE.addToLang('',{
preview_desc : 'Voorbeeld'
});
