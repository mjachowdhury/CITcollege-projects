// nn = Norwegian (nynorsk) lang variables by Knut B. Jacobsen

tinyMCE.addToLang('',{
paste_text_desc : 'Lim inn som vanleg tekst',
paste_text_title : 'Bruk CTRL+V p&aring; tastaturet ditt for &aring; lime inn i dette vindauget.',
paste_text_linebreaks : 'Spar linjebrudd',
paste_word_desc : 'Lim inn fr� Office (Word)',
paste_word_title : 'Bruk CTRL+V p&aring; tastaturet ditt for &aring; lime inn i dette vindauget.',
selectall_desc : 'Velg alt'
});
