// Iceland lang variables by Johannes Birgir Jensson

tinyMCE.addToLang('',{
print_desc : 'Prenta'
});
