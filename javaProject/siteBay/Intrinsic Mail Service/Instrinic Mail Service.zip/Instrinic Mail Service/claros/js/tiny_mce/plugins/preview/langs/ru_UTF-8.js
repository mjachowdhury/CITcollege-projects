// RU lang variables UTF-8

tinyMCE.addToLang('',{
preview_desc : 'Предварительный просмотр'
});
