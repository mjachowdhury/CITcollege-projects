/**
 * pt_br lang variables
 * Brazilian Portuguese
 *
 * Authors :
 *           Marcio Barbosa (mpg) <mpg@mpg.com.br>
 * Last Updated : November 26, 2005
 * TinyMCE Version : 2.0RC4
 */
tinyMCE.addToLang('',{
template_title : 'Este � s� um mod�lo de popup',
template_desc : 'Este � s� um mod�lo de bot�o'
});
