// Iceland lang variables by Johannes Birgir Jensson

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Finna',
searchreplace_searchnext_desc : 'Finna aftur',
searchreplace_replace_desc : 'Finna/skipta',
searchreplace_notfound : 'Leit er loki�. Leitaror� fannst ekki.',
searchreplace_search_title : 'Finna',
searchreplace_replace_title : 'Finna/skipta',
searchreplace_allreplaced : 'Skipt var um �ll tilvik.',
searchreplace_findwhat : 'Finna hvar',
searchreplace_replacewith : 'Skipta &uacute;t fyrir ',
searchreplace_direction : '&Aacute;tt',
searchreplace_up : 'Upp',
searchreplace_down : 'Ni&eth;ur',
searchreplace_case : 'Passa h&aacute;-/l&aacute;gstafi',
searchreplace_findnext : 'Finna&nbsp;n&aelig;st',
searchreplace_replace : 'Skipta',
searchreplace_replaceall : 'Skipta&nbsp;&ouml;llum',
searchreplace_cancel : 'H&aelig;tta vi&eth;',
searchreplace_replace_delta_width : 30
});
