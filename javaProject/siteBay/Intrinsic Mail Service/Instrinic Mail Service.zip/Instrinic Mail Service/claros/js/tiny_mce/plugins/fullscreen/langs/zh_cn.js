// Simplified Chinese lang variables contributed by tom_cat (thomaswangyang@gmail.com)

tinyMCE.addToLang('',{
fullscreen_title : 'ȫ��ģʽ',
fullscreen_desc : '�л�ȫ��ģʽ'
});
