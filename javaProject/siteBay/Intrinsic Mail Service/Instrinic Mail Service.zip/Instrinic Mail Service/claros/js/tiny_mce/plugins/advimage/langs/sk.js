/**
 * Slovak lang variables 
 * encoding: utf-8
 * 
 * @author Vladimir VASIL vvasil@post.sk
 *    
 * $Id: sk.js,v 1.1 2005/11/22 20:56:44 spocke Exp $ 
 */  


tinyMCE.addToLang('',{
insert_image_alt2 : 'Názov obrázku',
insert_image_onmousemove : 'Alternatívny obrázok',
insert_image_mouseover : 'pri najet? myšou',
insert_image_mouseout : 'pri odjet? myšou'
});
