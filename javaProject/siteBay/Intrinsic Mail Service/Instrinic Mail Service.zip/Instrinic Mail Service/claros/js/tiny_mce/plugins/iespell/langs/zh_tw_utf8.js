// Traditional Chinese UTF-8; Twapweb Site translated; twapweb_AT_gmail_DOT_com
// 繁體中文 UTF-8 ；數位應用坊製作； twapweb_AT_gmail_DOT_com

tinyMCE.addToLang('',{
iespell_desc : '執行拼字檢查',
iespell_download : "無 ieSpell 拼字檢查功能。點按「確定」後下載安裝"
});

