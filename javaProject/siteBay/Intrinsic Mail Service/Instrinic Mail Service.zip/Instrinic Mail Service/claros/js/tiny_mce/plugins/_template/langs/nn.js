// nn = Norwegian (nynorsk) lang variables by Knut B. Jacobsen

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */

tinyMCE.addToLang('',{
template_title : 'Dette er berre ein template popup',
template_desc : 'Dette er berre ein template knapp'
});
