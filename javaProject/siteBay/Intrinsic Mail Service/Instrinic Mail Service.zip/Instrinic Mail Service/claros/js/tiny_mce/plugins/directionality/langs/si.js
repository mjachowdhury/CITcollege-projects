// SI lang variables ISO-8859-2

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Smer od leve proti desni',
directionality_rtl_desc : 'Smer od desne proti levi'
});
