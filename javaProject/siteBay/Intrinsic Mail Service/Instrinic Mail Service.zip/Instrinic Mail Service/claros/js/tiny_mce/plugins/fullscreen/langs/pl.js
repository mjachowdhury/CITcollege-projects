// PL lang variables
// fixed by Wooya
// http://www.mfusion.prv.pl
// fixed by lemiel 14.11.2005

tinyMCE.addToLang('',{
fullscreen_title : 'Tryb pe�noekranowy',
fullscreen_desc : 'Prze��cz w tryb pe�noekranowy'
});
