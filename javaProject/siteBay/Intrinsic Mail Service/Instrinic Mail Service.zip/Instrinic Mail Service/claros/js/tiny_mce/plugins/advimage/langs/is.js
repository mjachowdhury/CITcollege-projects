// Iceland lang variables by Johannes Birgir Jensson

tinyMCE.addToLang('advimage',{
tab_general : 'A&eth;alstillingar',
tab_appearance : '&Uacute;tlit',
tab_advanced : 'Fl&oacute;knari valkostir',
general : 'Helstu uppl&yacute;singar',
title : 'Titill',
preview : 'Forsko&eth;un',
constrain_proportions : 'Vernda hlutf&ouml;ll',
langdir : 'Rith&aacute;ttur tungum&aacute;ls',
langcode : 'Tungum&aacute;lsk&oacute;&eth;i',
long_desc : 'Tengill &aacute; &iacute;tarl&yacute;singu',
style : 'St&iacute;ll',
classes : 'Klassi',
ltr : 'Vinstri til h&aelig;gri',
rtl : 'H&aelig;gri til vinstri',
id : 'Id',
image_map : 'Myndarkort',
swap_image : 'Skipta mynd',
alt_image : 'Skiptimynd',
mouseover : '&thorn;egar m&uacute;s fer yfir',
mouseout : '&thorn;egar m&uacute;s fer fr&aacute;',
misc : '&Yacute;mislegt',
example_img : 'Forsko&eth;unarmynd',
missing_alt : 'Ertu viss um a&eth; &thorn;&uacute; viljir halda &aacute;fram &aacute;n myndarl&yacute;singar? &Aacute;n hennar munu sumir notendur, eins og fatla&eth;ir e&eth;a me&eth; gamla vafra ekki geta s&eacute;&eth; myndina.'
});
