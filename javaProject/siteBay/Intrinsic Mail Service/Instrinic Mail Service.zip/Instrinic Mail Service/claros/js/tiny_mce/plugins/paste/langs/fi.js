// FI lang variables by Tuomo Aura, Ateco.fi

tinyMCE.addToLang('',{
paste_text_desc : 'Liit&auml; tavallisena tekstin&auml;',
paste_text_title : 'Paina CTRL+V liitt&auml;&auml;ksesi leikkaamasi/kopioimasi tekstin ikkunaan.',
paste_text_linebreaks : 'S&auml;ilyt&auml; rivinvaihdot',
paste_word_desc : 'Liit&auml; Wordista',
paste_word_title : 'Paina CTRL+V liitt&auml;&auml;ksesi leikkaamasi/kopioimasi tekstin ikkunaan.',
selectall_desc : 'Valitse kaikki'
});
