// PL lang variables
// fixed by lemiel 14.11.2005

tinyMCE.addToLang('advimage',{
tab_general : 'G��wne ustawienia',
tab_appearance : 'Widok',
tab_advanced : 'Zaawansowane',
general : 'G��wne',
title : 'Tytu�',
preview : 'Podgl�d',
constrain_proportions : 'Zachowaj proporcje',
langdir : 'Kierunek tekstu',
langcode : 'Kod j�zyka',
long_desc : 'D�ugi opis linku',
style : 'Styl',
classes : 'Klasy',
ltr : 'Lewy do prawego',
rtl : 'Prawy do lewego',
id : 'Id',
image_map : 'Mapa obrazka',
swap_image : 'Podmiana obrazka',
alt_image : 'Alternatywny obrazek',
mouseover : 'gdy myszka nad obrazkiem',
mouseout : 'gdy myszka poza obrazkiem',
misc : 'R�ne',
example_img : 'Przyk�adowy&nbsp;podgl�d&nbsp;obrazka',
missing_alt : 'Czy jeste� pewien, �e chcesz kontynuowa� bez zawarcia opisu obrazka? Niekt�rzy u�ytkownicy moga u�ywa� przegl�darek tekstowych, lub mie� ograniczenia na wy�wietlanie grafik, a wtedy Tw�j obrazek pozostanie dla nich niewidoczny.'
});
