This project contains Doug Lea's util.concurrent library packaged
as an Eclipse plugin.  Since Doug didn't specify a license other
than that he obviously distributed his code in order for other people
to benefit from, I have not added any license to it.

Doug Lea's original work can be found at:

http://gee.cs.oswego.edu/dl/classes/EDU/oswego/cs/dl/util/concurrent/intro.html

