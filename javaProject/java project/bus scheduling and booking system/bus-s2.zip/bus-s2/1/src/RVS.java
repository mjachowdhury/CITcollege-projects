/**
 * AWT Sample application
 *
 * @author 
 * @version 1.00 07/08/09
 */
public class RVS {
    
    public static void main(String[] args) {
        // Create application frame.
        RVSFrame frame = new RVSFrame();
        
        // Show frame
        frame.setVisible(true);
    }
}
