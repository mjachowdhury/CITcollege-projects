import java.util.*;
class hashsetcl{
  public static void main(String args[])
 {
   HashSet hash=new HashSet();
   hash.add("A");
   hash.add("C");
   hash.add("F");
   hash.add("E");
   System.out.println(hash);
  }
}
 
