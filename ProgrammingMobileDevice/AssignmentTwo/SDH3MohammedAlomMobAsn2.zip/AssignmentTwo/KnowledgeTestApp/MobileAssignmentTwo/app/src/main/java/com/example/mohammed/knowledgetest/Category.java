package com.example.mohammed.knowledgetest;

/**
 * Mohammed Alom
 * Student No -R00144214
 * SDH3 - Assignment No 2
 */
public class Category {
    /**
     * Constant for selecting the category of the Quiz
     */
    public static final int PROGRAMMING = 1;
    public static final int NETWORKING = 2;
    public static final int DATABASE = 3;

    /**
     * id is for the category ID
     * name variable is for category name
     */
    private int id;
    private String name;

    public Category() {
    }

    public Category(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return getName();
    }
}
