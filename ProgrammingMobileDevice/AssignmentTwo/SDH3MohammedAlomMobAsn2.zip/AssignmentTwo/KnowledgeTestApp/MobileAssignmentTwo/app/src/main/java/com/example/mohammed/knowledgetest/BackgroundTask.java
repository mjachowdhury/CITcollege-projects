package com.example.mohammed.knowledgetest;

/**
 * Mohammed Alom
 * Student No -R00144214
 * SDH3 - Assignment No 2
 */

import android.content.Intent;
import android.media.MediaPlayer;
import android.provider.Settings;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

/**
 * In this class i have implemented two way set on click listener one is
 * starting inside the xml file and other one is implements View.OnCLickListener
 * and both way is working.
 */
public class BackgroundTask extends AppCompatActivity implements View.OnClickListener {

    private EditText editTextInput; //this one is for input text to check notification is working or not

    private Button start, stop; //this two button for the ringtone start and stop

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_background_task);

        editTextInput = findViewById(R.id.edit_text_input);

        //
        start = findViewById(R.id.buttonStartMusic);
        stop = findViewById(R.id.buttonStopMusic);

        start.setOnClickListener(this);
        stop.setOnClickListener(this);
    }

    /**
     * this method is for to start the service
     *
     * @param v
     */
    //implementing the onClick service for start and stop button
    public void startService(View v) {
        String input = editTextInput.getText().toString();

        Intent serviceIntent = new Intent(this, ExampleBackgroundService.class);
        serviceIntent.putExtra("inputExtra", input);

        //startService(serviceIntent);//this will work

        //startService work only API 26 upper but with this ContextCompat
        //it will check internally which api it is then it will start either
        //startService or startForegroundService Ctrl+ b will show the implementation
        ContextCompat.startForegroundService(this, serviceIntent);
    }

    /**
     * this method is for the to stop the service
     *
     * @param v
     */
    public void stopService(View v) {

        Intent serviceIntent = new Intent(this, ExampleBackgroundService.class);
        stopService(serviceIntent);
    }

    /**
     * This method is for the onClick lister for start and stop service for the ringtone in the background
     * when you implement in the main class View.OnClicklistener then onClick method have to do
     *
     * @param v
     */
    @Override
    public void onClick(View v) {
        if (v == start) {
            startService(new Intent(this, ExampleBackgroundService.class));
        } else if (v == stop) {
            stopService(new Intent(this, ExampleBackgroundService.class));
        }
    }
}