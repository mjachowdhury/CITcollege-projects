package com.example.mohammed.knowledgetest;

/**
 * Mohammed Alom
 * Student No -R00144214
 * SDH3 - Assignment No 2
 */

import android.content.Intent;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * This class will implement the gesture functionality. user can fling different screen
 * without pressing the button.
 */
public class Canvas extends AppCompatActivity implements GestureDetector.OnGestureListener {

    private TextView textViewCanvas;
    private GestureDetectorCompat detector;

    private Button buttonCanvas;
    private Button buttonDraw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_canvas);

        textViewCanvas = findViewById(R.id.textViewCanvas);

        buttonDraw = findViewById(R.id.buttonDraw);
        buttonCanvas = findViewById(R.id.buttonCanvas);

        buttonCanvas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGesture();
            }
        });

        buttonDraw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDraw();
            }
        });

        //this is for the gesture to go one pageto another page without pressing the button just fling
        //for this i have to implement -implements GestureDetector.OnGestureListener on the main class on top
        //that will implement more method built in gesture method

        detector = new GestureDetectorCompat(this, this);

    }

    /**
     * This method will open the Gesture.class page
     */
    private void openGesture() {
        Intent intentShowGesture = new Intent(this, Gesture.class);
        startActivity(intentShowGesture);
    }

    /**
     * This method will take to the DrawSomething Class page
     */
    private void openDraw() {
        Intent intentShowDraw = new Intent(this, DrawOnCanvas.class);
        startActivity(intentShowDraw);
    }

    @Override
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    /**
     * I have implement only fling so the user can swipe the page to go one from the another page.vis vs sa
     *
     * @param e1
     * @param e2
     * @param velocityX
     * @param velocityY
     * @return
     */
    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {

        Intent gestureShowIntent = new Intent(this, Gesture.class);
        startActivity(gestureShowIntent);
        //return false;
        return true;
    }

    /**
     * this method is for in-case onFling method not working then onTouchEvent will do
     *
     * @param event
     * @return
     */
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        detector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }
}
