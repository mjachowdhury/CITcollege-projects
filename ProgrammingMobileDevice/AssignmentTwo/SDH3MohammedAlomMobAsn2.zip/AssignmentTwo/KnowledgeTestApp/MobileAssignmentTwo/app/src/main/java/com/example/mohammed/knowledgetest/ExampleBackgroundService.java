package com.example.mohammed.knowledgetest;

/**
 * Mohammed Alom
 * Student No -R00144214
 * SDH3 - Assignment No 2
 */

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;

import static com.example.mohammed.knowledgetest.App.CHANNEL_ID;

public class ExampleBackgroundService extends Service {
    private MediaPlayer player;

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        //this is how to run ringtone in the background
        //this is working playing ringtone in the background
        player = MediaPlayer.create(this, Settings.System.DEFAULT_NOTIFICATION_URI);
        player.setLooping(true);
        player.start();

        // Above is the media player example
        String input = intent.getStringExtra("inputExtra");

        //creating notification
        Intent notificationIntent = new Intent(this, BackgroundTask.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,
                0, notificationIntent, 0);

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Example Service")
                .setContentText(input)
                .setSmallIcon(R.drawable.ic_android)
                .setContentIntent(pendingIntent)
                .build();

        startForeground(1, notification);

        //stopSelf();//this will stop the service
        return START_NOT_STICKY;
        //return START_STICKY; // This return for the MediaPlayer
        //return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        //player.stop();//This player.stop() method is for the media player
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
