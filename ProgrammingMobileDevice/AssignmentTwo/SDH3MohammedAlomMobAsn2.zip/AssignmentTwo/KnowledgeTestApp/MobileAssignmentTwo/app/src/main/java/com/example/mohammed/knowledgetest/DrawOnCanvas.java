package com.example.mohammed.knowledgetest;

/**
 * Mohammed Alom
 * Student No -R00144214
 * SDH3 - Assignment No 2
 */

import android.graphics.Color;
import android.graphics.Rect;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


public class DrawOnCanvas extends AppCompatActivity {

    private DrawSomething drawSomething;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_draw_on_canvas);

        drawSomething = new DrawSomething(this);
        drawSomething.setBackgroundColor(Color.RED);
        setContentView(drawSomething);
    }
}


