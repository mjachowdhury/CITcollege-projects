package com.example.mohammed.knowledgetest;

/**
 * Mohammed Alom
 * Student No -R00144214
 * SDH3 - Assignment No 2
 */


import android.provider.BaseColumns;

/**
 * This class will be used for SQLite operation
 */
public final class QuizContract {

    private QuizContract() {
    } //Because of the private that no body can create an object from that class

    /**
     * this is another table in the database for the categories
     */
    public static class CategoriesTable implements BaseColumns {
        public static final String TABLE_NAME = "quiz_categories";
        public static final String COLUMN_NAME = "name";
    }

    //BaseColumns is a interface

    /**
     * This class is a table in the database.
     */
    public static class QuestionTable implements BaseColumns {
        //Constant will be used for sql lite databse
        public static final String TABLE_NAME = "quiz_question";
        public static final String COLUMN_QUESTION = "question";
        public static final String COLUMN_OPTION1 = "option1";
        public static final String COLUMN_OPTION2 = "option2";
        public static final String COLUMN_OPTION3 = "option3";
        public static final String COLUMN_ANSWER_NR = "answer_nr";
        public static final String COLUMN_DIFFICULTY = "difficulty"; //adding another column which is difficulty leverl
        public static final String COLUMN_CATEGORY_ID = "category_id";

    }
}
