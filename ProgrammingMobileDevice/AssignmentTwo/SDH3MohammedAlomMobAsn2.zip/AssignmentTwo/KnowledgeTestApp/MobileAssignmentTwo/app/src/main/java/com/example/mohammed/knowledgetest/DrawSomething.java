package com.example.mohammed.knowledgetest;

/**
 * Mohammed Alom
 * Student No -R00144214
 * SDH3 - Assignment No 2
 */

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;

public class DrawSomething extends View {

    //Calling objects
    Paint paint;
    Rect rect;

    //constructor
    public DrawSomething(Context context) {
        super(context);
        //Creating the objects
        paint = new Paint();
        rect = new Rect();
    }

    /**
     * This method will draw a rectangle on canvas
     *
     * @param canvas
     */
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        rect.set(20, 20, canvas.getWidth() / 2, canvas.getHeight() / 2);

        paint.setColor(Color.BLUE);
        paint.setStrokeWidth(4);
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        canvas.drawRect(rect, paint);
    }
}
