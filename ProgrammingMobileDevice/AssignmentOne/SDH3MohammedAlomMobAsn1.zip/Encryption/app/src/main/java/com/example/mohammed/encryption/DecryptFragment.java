package com.example.mohammed.encryption;

import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.NotificationCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class DecryptFragment extends Fragment implements Button.OnClickListener {
    //View
    private Button buttonD;
    private EditText editTextD;
    private TextView textViewD;
    private Button buttonDR;
    private TextView textViewD1;
    private ImageButton buttonP;
    private Button pressMe;
    private Button mExit;

    //This is for the notification
    private int notificationId = 1234;

    //Empty Constructor
    public DecryptFragment() {
        // Required empty public constructor
    }

    //Calling all the buttons, edit text, text view and setting onClickListener method
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             final Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        final View view;
        view = inflater.inflate(R.layout.fragment_decrypt, container, false);//calling the fragment_decrypt xml file

        //getting all the id reference
        buttonD = (Button) view.findViewById(R.id.buttonD);
        editTextD = (EditText) view.findViewById((R.id.editTextD));
        textViewD = (TextView) view.findViewById((R.id.textViewD));
        buttonDR = (Button) view.findViewById(R.id.buttonDR);
        textViewD1 = (TextView) view.findViewById(R.id.textViewD1);
        buttonP = (ImageButton) view.findViewById(R.id.buttonP);
        pressMe = (Button) view.findViewById(R.id.press_me);
        mExit = (Button) view.findViewById(R.id.exit);

        buttonD.setOnClickListener(this);//this button for decrypt the text message
        buttonDR.setOnClickListener(this); // This button will clear all the text from the Text view field
        buttonP.setOnClickListener(this);//This button will pest the text

        /**
         * This setOnClickListener will perform exit operation
         * for the app. If user press no it will not exit.
         * If user press yes then it will exit the program.
         */
        mExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());
                // set title
                alertDialogBuilder.setTitle("Are you sure you want to exit!");
                // set dialog message
                alertDialogBuilder
                        .setMessage("Click yes to exit!")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // if this button is clicked, close
                                // current activity
                                //EncryptFragment.this.finish();
                                getActivity().finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // if this button is clicked, just close
                                // the dialog box and do nothing
                                dialog.cancel();
                            }
                        });

                // create alert dialog
                AlertDialog alertDialog = alertDialogBuilder.create();
                // show it
                alertDialog.show();
            }
        });

        /**
         *  This is for the notification when press the button press me by the user
         *  it will show the notification on the top of the screen.
         *  user have to slide from the top.
         */
        pressMe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:021 0000001"));
                PendingIntent pendingIntent = PendingIntent.getActivity(getContext(), 0, intent, 0);
                NotificationCompat.Builder mBuilder = (NotificationCompat.Builder) new NotificationCompat.Builder(getContext())
                        .setSmallIcon(R.drawable.ic_stat_name)
                        .setContentTitle("Phone notification")
                        .setContentText("Call Now!")
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        // Set the intent that will fire when the user taps the notification
                        .setContentIntent(pendingIntent)
                        .setAutoCancel(true);
                NotificationManagerCompat notificationManager = NotificationManagerCompat.from(getActivity());

                // notificationId is a unique int for each notification that you must define
                notificationManager.notify(notificationId, mBuilder.build());
            }
        });

        return view;
    }


    /**
     * Decrypt button method onClick()
     * here decryption logic implemented.
     *
     * @param view
     */

    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            //here actual decrypt button will work
            case R.id.buttonD:
                String text, dtext;
                text = String.valueOf(editTextD.getText());
                dtext = "";
                List<String> textList = new LinkedList<>(Arrays.asList(text.split("")));
                //Decrypt calculation algorithm
                int key, len;
                len = textList.size();
                key = (int) Math.floor(len / 3);
                for (int i = 0; i < key; i++) {
                    int j = i;
                    List<String> c = new ArrayList<>();
                    while (j < len) {
                        c.add(textList.get(j));
                        j = j + key;
                    }

                    int count, lenofc;
                    count = 0;
                    lenofc = c.size();
                    while (count < lenofc) {
                        dtext = dtext + c.get(count);
                        count += 1;
                    }
                    if (dtext.contains("*") == true) {
                        dtext = dtext.replace("*", "");

                    }
                    //This title will appear once the Decrypt button will press

                    textViewD1.setText("The decrypted text is:");
                    textViewD.setText(String.valueOf(dtext));
                    InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(
                            Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(editTextD.getWindowToken(), 0);
                }
                break;
            //here clear all the text button will work
            case R.id.buttonDR:
                textViewD.setText("");
                textViewD1.setText("");
                editTextD.setText("");
                break;

            //Here encrypted text pest button work
            case R.id.buttonP:
                ClipboardManager myClipBoard;
                myClipBoard = (ClipboardManager) this.getContext().getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData cp = myClipBoard.getPrimaryClip();
                ClipData.Item item = cp.getItemAt(0);
                String textP = item.getText().toString();
                editTextD.setText(textP);
                break;
        }
    }
}
