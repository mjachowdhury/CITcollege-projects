package com.example.mohammed.encryption;


import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.NotificationCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class EncryptFragment extends Fragment implements Button.OnClickListener {

    //View
    private Button buttonE;
    private EditText editTextE, name;
    private TextView textViewE;
    private Button buttonER;
    private TextView textViewE1;
    private ImageButton buttonShareE;
    private Button pressMe;
    private Button mExit;
    private Button respond;

    private int notificationId = 1234;
    private String savedName;

    //Empty Constructor
    public EncryptFragment() {
        // Required empty public constructor
    }


    //Calling all the button and setting onClickListener method
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             final Bundle savedInstanceState) {
        View view = null;
        view = inflater.inflate(R.layout.fragment_encrypt, container, false);

        buttonE = (Button) view.findViewById(R.id.buttonE);
        editTextE = (EditText) view.findViewById((R.id.editTextE));
        name = (EditText) view.findViewById(R.id.name);
        textViewE = (TextView) view.findViewById((R.id.textViewE));
        buttonER = (Button) view.findViewById(R.id.buttonER);
        textViewE1 = (TextView) view.findViewById(R.id.textViewE1);
        buttonShareE = (ImageButton) view.findViewById(R.id.buttonShareE);

        pressMe = (Button) view.findViewById(R.id.press_me);
        mExit = (Button) view.findViewById(R.id.exit);
        respond = (Button) view.findViewById(R.id.respond);

        buttonE.setOnClickListener(this);
        buttonER.setOnClickListener(this);
        buttonShareE.setOnClickListener(this);
        buttonShareE.setEnabled(false);

        //this is for alert button set on click listener
        mExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());
                // set title
                alertDialogBuilder.setTitle("Are you sure you want to exit!");
                // set dialog message
                alertDialogBuilder
                        .setMessage("Click yes to exit!")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // if this button is clicked, close
                                // current activity
                                //EncryptFragment.this.finish();
                                getActivity().finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // if this button is clicked, just close
                                // the dialog box and do nothing
                                dialog.cancel();
                            }
                        });
                // create alert dialog
                AlertDialog alertDialog = alertDialogBuilder.create();
                // show it
                alertDialog.show();
            }
        });
        //This is for notification when press the button press me
        pressMe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:021 0000001"));
                PendingIntent pendingIntent = PendingIntent.getActivity(getContext(), 0, intent, 0);
                NotificationCompat.Builder mBuilder = (NotificationCompat.Builder)
                        new NotificationCompat.Builder(getContext())
                                .setSmallIcon(R.drawable.ic_stat_name)
                                .setContentTitle("Phone notification")
                                .setContentText("Call Now!")
                                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                                // Set the intent that will fire when the user taps the notification
                                .setContentIntent(pendingIntent)
                                .setAutoCancel(true);
                NotificationManagerCompat notificationManager = NotificationManagerCompat.from(getActivity());

                // notificationId is a unique int for each notification that you must define
                notificationManager.notify(notificationId, mBuilder.build());
            }
        });


        //savedInstanceState() working logic
        if (savedInstanceState != null) {
            savedInstanceState.get(savedName);
            textViewE.setText(savedName);
        } else {
            //textViewE.setText("Hello! What is your name?");
            respond.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    savedName = editTextE.getText().toString();
                    textViewE.setText("Your saved text was : " + savedName);
                    //textViewE.setText(savedInstanceState.getString(savedName));
                }
            });
        }

        return view;
    }


    /**
     * Encrypt button method onClick()
     *
     * @param view
     */
    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.buttonE:
                String x = String.valueOf(editTextE.getText());
                final String y;
                y = Encrypt(x);
                buttonShareE.setEnabled(true);//user can share the encrypted text

                //calling the shareIt() method through setOnClickListener method
                buttonShareE.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        shareIt(y);
                    }
                });
                break;

            //if there no string input then this Clear All Button will tigger
            case R.id.buttonER:
                editTextE.setText("");
                textViewE.setText("");
                textViewE1.setText("");
                buttonShareE.setEnabled(false);
                break;
        }
    }


    /**
     * This method will encrypted the actual string message.
     *
     * @param text actual string
     * @return will return the encrypted string
     */
    private String Encrypt(String text) {
        String ctext;
        text = String.valueOf(editTextE.getText());
        ctext = "";
        //text=text.toLowerCase();
        //text=text.replace(" ","");

        List<String> textList = new LinkedList<>(Arrays.asList(text.split("")));

        //here encryption string calculation algorithm
        int len = textList.size();
        int lencheck = len % 3;
        if (lencheck != 0) {
            int lena = lencheck + 1;
            int lenb = lencheck + 2;
            if (lena % 3 == 0) {
                textList.add("*");
            } else if (lenb % 3 == 0) {
                textList.add("*");
                textList.add("*");
            }
        }
        len = textList.size();

        for (int i = 0; i < 3; i++) {
            int j = i;
            List<String> c = new ArrayList<>();
            while (j < len) {
                c.add(textList.get(j));
                j = j + 3;
            }

            int count, lenofc;
            count = 0;
            lenofc = c.size();
            while (count < lenofc) {
                ctext = ctext + c.get(count);
                count += 1;
            }
        }

        //This title will appear once the Encrypt button will press

        textViewE1.setText("The encrypted text is:");
        textViewE.setText(String.valueOf(ctext));

        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(
                Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(editTextE.getWindowToken(), 0);
        return ctext;
    }

    /**
     * This method is Intent if user want to share this is encrypted message then they can share
     * with other user but other user have to have same app to decrypt the message.
     *
     * @param shareCtext its share Crypted text
     */
    private void shareIt(String shareCtext) {
        Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        String shareBody = shareCtext;
        sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
        startActivity(Intent.createChooser(sharingIntent, "Share via"));
    }
}
