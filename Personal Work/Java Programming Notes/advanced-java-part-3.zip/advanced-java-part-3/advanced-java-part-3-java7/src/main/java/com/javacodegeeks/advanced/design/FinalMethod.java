package com.javacodegeeks.advanced.design;

public class FinalMethod {
    public final void performAction() {        
    }
}
