package com.javacodegeeks.advanced.design;

public final class FinalClass {

}
