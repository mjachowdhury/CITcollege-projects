package com.javacodegeeks.advanced.design;

public interface SimpleInterface {
    void performAction();
}
